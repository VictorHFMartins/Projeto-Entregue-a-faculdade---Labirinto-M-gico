package a3.modelo.cenario;

import java.awt.Rectangle;
import javax.swing.ImageIcon;

public class Tile {

    public ImageIcon img;
    public boolean colisao;
    public Rectangle r1;

}
